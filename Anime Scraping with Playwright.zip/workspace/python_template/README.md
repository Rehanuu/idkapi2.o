# Anime Scraper

A Python script using Playwright to scrape anime content from hianimez.is and rareanimes.co websites.

## Features

- Scrapes anime titles, thumbnails, and URLs from homepages
- Extracts detailed information from anime detail pages:
  - Description/synopsis
  - Genres
  - Release year/status
  - Episode list with links
  - Video sources (iframe/embed sources)
- Handles dynamic content loading with Playwright
- Includes retry logic and error handling
- Supports pagination through all available pages
- Supports filtering by genre or search term
- Can scrape a specific anime URL
- Saves results to a JSON file

## Installation

1. Clone the repository
2. Install dependencies:

```bash
pip install -r requirements.txt
playwright install
```

## Usage

Basic usage:

```bash
python main.py
```

### Command Line Options

- `--url`: Specify a single anime URL to scrape
- `--pages`: Number of pages to scrape (default: 1, use 0 for all pages)
- `--genre`: Filter anime by genre (hianimez only)
- `--search`: Search term (rareanimes only)
- `--no-headless`: Run the browser in non-headless mode (visible)
- `--output`: Specify output JSON file name (default: anime_data.json)

### Examples

Scrape first 3 pages from both sites:

```bash
python main.py --pages 3
```

Scrape a specific anime:

```bash
python main.py --url https://hianimez.is/anime/some-anime-title/
```

Filter by genre:

```bash
python main.py --genre action
```

Search by keyword:

```bash
python main.py --search "dragon ball"
```

Save to a custom file:

```bash
python main.py --output my_anime_data.json
```

## Output Format

The script generates a JSON file with the following structure:

```json
[
  {
    "title": "Anime Title",
    "thumbnail": "https://example.com/image.jpg",
    "url": "https://example.com/anime/title",
    "source": "hianimez",
    "description": "Anime description...",
    "genres": ["Action", "Comedy", "Drama"],
    "status": "Completed",
    "year": "2023",
    "episodes": [
      {
        "title": "Episode 1",
        "episode_number": "1",
        "url": "https://example.com/anime/title/episode-1"
      }
    ],
    "video_sources": [
      "https://example.com/embed/video123"
    ]
  }
]
```

## Logging

The script logs information to both a `scraper.log` file and the console.

## Note

This script is for educational purposes only. Please respect website terms of service and robots.txt when scraping websites.