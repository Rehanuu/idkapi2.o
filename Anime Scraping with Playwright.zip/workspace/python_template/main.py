#!/usr/bin/env python3
"""
Anime Scraper - A web scraper for anime content from hianimez.is and rareanimes.co
"""
import json
import os
import sys
import argparse
import asyncio
import logging
from typing import List, Dict, Any, Optional, Union

from playwright.async_api import async_playwright, Page, Browser
import requests
from bs4 import BeautifulSoup

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler("scraper.log"),
        logging.StreamHandler(sys.stdout)
    ]
)
logger = logging.getLogger("AnimeScraper")

# Constants
MAX_RETRIES = 3
RETRY_DELAY = 2  # seconds
OUTPUT_FILE = "anime_data.json"


class AnimeScraper:
    def __init__(self, headless: bool = True):
        """
        Initialize the anime scraper.
        
        Args:
            headless: Whether to run the browser in headless mode
        """
        self.headless = headless
        self.browser = None
        self.context = None
        self.hianimez_results = []
        self.rareanimes_results = []
        self.combined_results = []
        
    async def initialize(self):
        """Initialize the playwright browser."""
        playwright = await async_playwright().start()
        self.browser = await playwright.chromium.launch(headless=self.headless)
        self.context = await self.browser.new_context(
            user_agent="Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36"
        )
    
    async def close(self):
        """Close browser resources."""
        if self.context:
            await self.context.close()
        if self.browser:
            await self.browser.close()
    
    async def retry_page_action(self, action, *args, **kwargs):
        """Retry a page action with exponential backoff."""
        retries = 0
        while retries < MAX_RETRIES:
            try:
                return await action(*args, **kwargs)
            except Exception as e:
                retries += 1
                if retries >= MAX_RETRIES:
                    logger.error(f"Action failed after {MAX_RETRIES} attempts: {e}")
                    raise
                wait_time = RETRY_DELAY * (2 ** (retries - 1))
                logger.warning(f"Attempt {retries} failed, retrying in {wait_time}s. Error: {e}")
                await asyncio.sleep(wait_time)
    
    async def get_page(self, url: str) -> Page:
        """Create a new page and navigate to the URL."""
        page = await self.context.new_page()
        
        # Set default timeout
        page.set_default_timeout(30000)
        
        # Add page error handling
        page.on("console", lambda msg: logger.debug(f"Browser console: {msg.text}"))
        page.on("pageerror", lambda err: logger.error(f"Page error: {err}"))
        
        try:
            await page.goto(url, wait_until="networkidle")
            return page
        except Exception as e:
            await page.close()
            raise Exception(f"Failed to navigate to {url}: {e}")
    
    async def scrape_hianimez(self, page_limit: int = 1, specific_url: Optional[str] = None, genre: Optional[str] = None):
        """
        Scrape anime data from hianimez.is
        
        Args:
            page_limit: Number of pages to scrape (0 for all)
            specific_url: Specific anime URL to scrape
            genre: Genre to filter by
        """
        logger.info("Starting to scrape hianimez.is")
        
        if specific_url:
            await self._scrape_hianimez_anime_details(specific_url)
            return
            
        base_url = "https://hianimez.is"
        current_page = 1
        
        # Construct URL based on filters
        url = base_url
        if genre:
            url = f"{base_url}/genre/{genre}"
        
        while True:
            page_url = f"{url}/page/{current_page}" if current_page > 1 else url
            logger.info(f"Scraping HiAnimez page {current_page}: {page_url}")
            
            try:
                page = await self.get_page(page_url)
                
                # Check if we've reached the end of the pages
                end_text = await page.query_selector('.hpage .pages')
                if end_text and "Page not found" in await end_text.inner_text():
                    logger.info("Reached the end of available pages")
                    await page.close()
                    break
                
                # Extract anime entries
                anime_cards = await page.query_selector_all('.listupd .excstf article')
                if not anime_cards:
                    logger.warning(f"No anime cards found on page {current_page}")
                    await page.close()
                    break
                
                for card in anime_cards:
                    try:
                        title_elem = await card.query_selector('h2.entry-title a')
                        title = await title_elem.inner_text() if title_elem else "Unknown Title"
                        
                        link = await title_elem.get_attribute('href') if title_elem else None
                        
                        img_elem = await card.query_selector('img')
                        thumbnail = await img_elem.get_attribute('src') if img_elem else None
                        
                        anime_data = {
                            "title": title.strip(),
                            "thumbnail": thumbnail,
                            "url": link,
                            "source": "hianimez"
                        }
                        
                        self.hianimez_results.append(anime_data)
                        logger.debug(f"Found anime: {title}")
                        
                    except Exception as e:
                        logger.error(f"Error extracting anime card data: {e}")
                
                await page.close()
                
                # Break if we've reached the page limit
                if page_limit > 0 and current_page >= page_limit:
                    logger.info(f"Reached page limit ({page_limit})")
                    break
                
                current_page += 1
                
            except Exception as e:
                logger.error(f"Error scraping page {current_page}: {e}")
                break
        
        # Get detailed info for each anime
        for idx, anime in enumerate(self.hianimez_results):
            if anime.get("url"):
                logger.info(f"Fetching details for {anime['title']} ({idx+1}/{len(self.hianimez_results)})")
                try:
                    await self._scrape_hianimez_anime_details(anime["url"], anime)
                except Exception as e:
                    logger.error(f"Failed to get details for {anime['title']}: {e}")
    
    async def _scrape_hianimez_anime_details(self, url: str, anime_data: Optional[Dict] = None):
        """Scrape detailed information for a HiAnimez anime."""
        try:
            page = await self.get_page(url)
            
            # Initialize anime_data if not provided
            if not anime_data:
                title_elem = await page.query_selector('.infox h1.entry-title')
                title = await title_elem.inner_text() if title_elem else "Unknown Title"
                
                img_elem = await page.query_selector('.thumb img')
                thumbnail = await img_elem.get_attribute('src') if img_elem else None
                
                anime_data = {
                    "title": title.strip(),
                    "thumbnail": thumbnail,
                    "url": url,
                    "source": "hianimez"
                }
                self.hianimez_results.append(anime_data)
            
            # Get synopsis
            synopsis_elem = await page.query_selector('.entry-content p')
            if synopsis_elem:
                anime_data["description"] = (await synopsis_elem.inner_text()).strip()
            
            # Get genres
            genres_elem = await page.query_selector('.genxed')
            if genres_elem:
                genre_links = await genres_elem.query_selector_all('a')
                anime_data["genres"] = [await link.inner_text() for link in genre_links]
            
            # Get release info
            info_items = await page.query_selector_all('.info-content .spe span')
            for item in info_items:
                text = await item.inner_text()
                if "Status:" in text:
                    anime_data["status"] = text.replace("Status:", "").strip()
                elif "Released:" in text or "Year:" in text:
                    anime_data["year"] = text.split(":")[-1].strip()
            
            # Get episodes
            episodes = []
            episode_items = await page.query_selector_all('#episodelist li')
            for ep_item in episode_items:
                ep_link = await ep_item.query_selector('a')
                if ep_link:
                    ep_url = await ep_link.get_attribute('href')
                    ep_title = await ep_link.inner_text()
                    
                    # Extract episode number
                    ep_num = "Unknown"
                    if "Episode" in ep_title:
                        try:
                            ep_num = ep_title.split("Episode")[-1].strip()
                        except:
                            pass
                    
                    episodes.append({
                        "title": ep_title.strip(),
                        "episode_number": ep_num,
                        "url": ep_url
                    })
            
            anime_data["episodes"] = episodes
            
            # Try to get a video source for the first episode
            if episodes and "url" in episodes[0]:
                try:
                    ep_page = await self.get_page(episodes[0]["url"])
                    
                    # Look for iframes
                    iframes = await ep_page.query_selector_all('iframe')
                    video_sources = []
                    
                    for iframe in iframes:
                        src = await iframe.get_attribute('src')
                        if src:
                            video_sources.append(src)
                    
                    # Look for video tags
                    video_tags = await ep_page.query_selector_all('video source')
                    for video in video_tags:
                        src = await video.get_attribute('src')
                        if src:
                            video_sources.append(src)
                    
                    anime_data["video_sources"] = video_sources
                    await ep_page.close()
                except Exception as e:
                    logger.error(f"Error fetching video sources: {e}")
            
            await page.close()
            
        except Exception as e:
            logger.error(f"Error scraping anime details from {url}: {e}")
            
    async def scrape_rareanimes(self, page_limit: int = 1, specific_url: Optional[str] = None, search_term: Optional[str] = None):
        """
        Scrape anime data from rareanimes.co
        
        Args:
            page_limit: Number of pages to scrape (0 for all)
            specific_url: Specific anime URL to scrape
            search_term: Search term to filter by
        """
        logger.info("Starting to scrape rareanimes.co")
        
        if specific_url:
            await self._scrape_rareanimes_anime_details(specific_url)
            return
            
        base_url = "https://www.rareanimes.co"
        current_page = 1
        
        # Construct URL based on filters
        url = base_url
        if search_term:
            url = f"{base_url}/search?keyword={search_term}"
        
        while True:
            page_url = f"{url}?page={current_page}" if current_page > 1 else url
            logger.info(f"Scraping RareAnimes page {current_page}: {page_url}")
            
            try:
                page = await self.get_page(page_url)
                
                # Check if we've reached the end of the pages
                next_button = await page.query_selector('.pagination .next')
                no_next_page = not next_button or await next_button.get_attribute('disabled') == 'true'
                
                # Extract anime entries
                anime_cards = await page.query_selector_all('.anime-list .anime-card')
                if not anime_cards:
                    logger.warning(f"No anime cards found on page {current_page}")
                    await page.close()
                    break
                
                for card in anime_cards:
                    try:
                        title_elem = await card.query_selector('.anime-title a')
                        title = await title_elem.inner_text() if title_elem else "Unknown Title"
                        
                        link = await title_elem.get_attribute('href') if title_elem else None
                        if link and not link.startswith('http'):
                            link = base_url + link
                        
                        img_elem = await card.query_selector('img.anime-poster')
                        thumbnail = await img_elem.get_attribute('src') if img_elem else None
                        
                        anime_data = {
                            "title": title.strip(),
                            "thumbnail": thumbnail,
                            "url": link,
                            "source": "rareanimes"
                        }
                        
                        self.rareanimes_results.append(anime_data)
                        logger.debug(f"Found anime: {title}")
                        
                    except Exception as e:
                        logger.error(f"Error extracting anime card data: {e}")
                
                await page.close()
                
                # Break if we've reached the page limit or no more pages
                if (page_limit > 0 and current_page >= page_limit) or no_next_page:
                    if no_next_page:
                        logger.info("Reached the end of available pages")
                    else:
                        logger.info(f"Reached page limit ({page_limit})")
                    break
                
                current_page += 1
                
            except Exception as e:
                logger.error(f"Error scraping page {current_page}: {e}")
                break
        
        # Get detailed info for each anime
        for idx, anime in enumerate(self.rareanimes_results):
            if anime.get("url"):
                logger.info(f"Fetching details for {anime['title']} ({idx+1}/{len(self.rareanimes_results)})")
                try:
                    await self._scrape_rareanimes_anime_details(anime["url"], anime)
                except Exception as e:
                    logger.error(f"Failed to get details for {anime['title']}: {e}")
    
    async def _scrape_rareanimes_anime_details(self, url: str, anime_data: Optional[Dict] = None):
        """Scrape detailed information for a RareAnimes anime."""
        try:
            page = await self.get_page(url)
            
            # Initialize anime_data if not provided
            if not anime_data:
                title_elem = await page.query_selector('.anime-title')
                title = await title_elem.inner_text() if title_elem else "Unknown Title"
                
                img_elem = await page.query_selector('.anime-cover img')
                thumbnail = await img_elem.get_attribute('src') if img_elem else None
                
                anime_data = {
                    "title": title.strip(),
                    "thumbnail": thumbnail,
                    "url": url,
                    "source": "rareanimes"
                }
                self.rareanimes_results.append(anime_data)
            
            # Get synopsis
            synopsis_elem = await page.query_selector('.anime-synopsis')
            if synopsis_elem:
                anime_data["description"] = (await synopsis_elem.inner_text()).strip()
            
            # Get genres
            genres_elem = await page.query_selector('.anime-genres')
            if genres_elem:
                genre_links = await genres_elem.query_selector_all('a')
                anime_data["genres"] = [await link.inner_text() for link in genre_links]
            
            # Get release info
            info_items = await page.query_selector_all('.anime-info .info-item')
            for item in info_items:
                label_elem = await item.query_selector('.label')
                value_elem = await item.query_selector('.value')
                
                if label_elem and value_elem:
                    label = await label_elem.inner_text()
                    value = await value_elem.inner_text()
                    
                    if "Status" in label:
                        anime_data["status"] = value.strip()
                    elif "Year" in label or "Released" in label:
                        anime_data["year"] = value.strip()
            
            # Get episodes
            episodes = []
            episode_items = await page.query_selector_all('.episode-list .episode-item')
            for ep_item in episode_items:
                ep_link = await ep_item.query_selector('a')
                if ep_link:
                    ep_url = await ep_link.get_attribute('href')
                    if ep_url and not ep_url.startswith('http'):
                        ep_url = "https://www.rareanimes.co" + ep_url
                        
                    ep_title_elem = await ep_item.query_selector('.episode-title')
                    ep_title = await ep_title_elem.inner_text() if ep_title_elem else "Unknown Episode"
                    
                    ep_num_elem = await ep_item.query_selector('.episode-number')
                    ep_num = await ep_num_elem.inner_text() if ep_num_elem else "Unknown"
                    
                    episodes.append({
                        "title": ep_title.strip(),
                        "episode_number": ep_num.strip(),
                        "url": ep_url
                    })
            
            anime_data["episodes"] = episodes
            
            # Try to get a video source for the first episode
            if episodes and "url" in episodes[0]:
                try:
                    ep_page = await self.get_page(episodes[0]["url"])
                    
                    # Look for iframes
                    iframes = await ep_page.query_selector_all('iframe')
                    video_sources = []
                    
                    for iframe in iframes:
                        src = await iframe.get_attribute('src')
                        if src:
                            video_sources.append(src)
                    
                    # Look for video tags
                    video_tags = await ep_page.query_selector_all('video source')
                    for video in video_tags:
                        src = await video.get_attribute('src')
                        if src:
                            video_sources.append(src)
                    
                    anime_data["video_sources"] = video_sources
                    await ep_page.close()
                except Exception as e:
                    logger.error(f"Error fetching video sources: {e}")
            
            await page.close()
            
        except Exception as e:
            logger.error(f"Error scraping anime details from {url}: {e}")
    
    def combine_results(self):
        """Combine results from both sites into one list."""
        self.combined_results = self.hianimez_results + self.rareanimes_results
    
    def save_to_file(self, filename: str = OUTPUT_FILE):
        """Save scraped data to a JSON file."""
        try:
            with open(filename, 'w', encoding='utf-8') as f:
                json.dump(self.combined_results, f, indent=2, ensure_ascii=False)
            logger.info(f"Data saved to {filename}")
            return True
        except Exception as e:
            logger.error(f"Error saving data to {filename}: {e}")
            return False


async def main():
    """Main entry point for the script."""
    parser = argparse.ArgumentParser(description='Anime scraper for hianimez.is and rareanimes.co')
    parser.add_argument('--url', type=str, help='Specific anime URL to scrape')
    parser.add_argument('--pages', type=int, default=1, help='Number of pages to scrape (0 for all)')
    parser.add_argument('--genre', type=str, help='Filter anime by genre (hianimez)')
    parser.add_argument('--search', type=str, help='Search term (rareanimes)')
    parser.add_argument('--no-headless', action='store_true', help='Run browser in non-headless mode')
    parser.add_argument('--output', type=str, default=OUTPUT_FILE, help='Output JSON file name')
    args = parser.parse_args()
    
    scraper = AnimeScraper(headless=not args.no_headless)
    
    try:
        await scraper.initialize()
        
        # If specific URL is provided, determine the source
        if args.url:
            logger.info(f"Scraping specific URL: {args.url}")
            if "hianimez.is" in args.url:
                await scraper.scrape_hianimez(specific_url=args.url)
            elif "rareanimes.co" in args.url:
                await scraper.scrape_rareanimes(specific_url=args.url)
            else:
                logger.error("Unsupported URL domain. Please use hianimez.is or rareanimes.co URLs.")
        else:
            # Otherwise scrape both sites
            await scraper.scrape_hianimez(page_limit=args.pages, genre=args.genre)
            await scraper.scrape_rareanimes(page_limit=args.pages, search_term=args.search)
        
        scraper.combine_results()
        
        # Save to file
        scraper.save_to_file(args.output)
        
        # Print summary
        logger.info(f"Total anime scraped: {len(scraper.combined_results)}")
        logger.info(f"  - HiAnimez: {len(scraper.hianimez_results)}")
        logger.info(f"  - RareAnimes: {len(scraper.rareanimes_results)}")
        
    except Exception as e:
        logger.error(f"Error during scraping: {e}")
    
    finally:
        await scraper.close()


if __name__ == "__main__":
    asyncio.run(main())