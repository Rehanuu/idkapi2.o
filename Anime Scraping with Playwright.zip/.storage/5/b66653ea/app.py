from flask import Flask, request, jsonify, render_template
import subprocess
import os
import json

app = Flask(__name__)

@app.route('/')
def home():
    return render_template('index.html')

@app.route('/scrape', methods=['POST'])
def scrape():
    try:
        # Extract parameters from the request
        url = request.json.get('url', None)
        pages = request.json.get('pages', 1)
        genre = request.json.get('genre', None)
        search = request.json.get('search', None)
        output = request.json.get('output', 'anime_data.json')

        # Build the command
        command = ['python', 'main.py', '--output', output]
        if url:
            command.extend(['--url', url])
        if pages:
            command.extend(['--pages', str(pages)])
        if genre:
            command.extend(['--genre', genre])
        if search:
            command.extend(['--search', search])

        # Run the scraper
        result = subprocess.run(command, capture_output=True, text=True)

        # Check if the output file exists
        if os.path.exists(output):
            with open(output, 'r') as file:
                data = json.load(file)
            return jsonify(data)
        else:
            return jsonify({"error": "Scraping failed", "details": result.stderr}), 500

    except Exception as e:
        return jsonify({"error": str(e)}), 500

if __name__ == '__main__':
    app.run(debug=True)